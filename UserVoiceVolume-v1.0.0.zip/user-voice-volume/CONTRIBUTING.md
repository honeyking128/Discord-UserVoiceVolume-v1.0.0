# Contributing

Thanks for helping improve UserVoiceVolume.

## Bug reports

Please include:
- Discord version
- BetterDiscord version
- plugin version
- what you expected
- what happened instead
- relevant console errors, with private information removed

## Pull requests

Keep changes focused and explain why they are needed. Test the plugin in the current desktop Discord/BetterDiscord release before opening a PR. Do not add telemetry, tracking, credential collection, or unrelated network requests.
