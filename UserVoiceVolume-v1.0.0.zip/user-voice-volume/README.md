# UserVoiceVolume 🔊

A small open-source BetterDiscord plugin that adds quick **per-user voice volume presets up to 300%** to Discord's user context menu.

> This is an unofficial community project. It is not affiliated with Discord or BetterDiscord.

## Features

- Per-user presets: **25%, 50%, 100%, 150%, 200%, 250%, 300%**
- Remembers the last preset selected for each user
- Adds controls directly to the Discord user context menu
- No external services, accounts, analytics, or telemetry
- Single-file plugin

## Requirements

1. Desktop Discord
2. BetterDiscord installed from the official BetterDiscord website
3. A current BetterDiscord version exposing the required `BdApi` APIs

## Installation — Windows

1. Download `UserVoiceVolume.plugin.js` from this repository.
2. Open Discord.
3. Go to **User Settings → BetterDiscord → Plugins**.
4. Click **Open Plugins Folder**.
5. Copy `UserVoiceVolume.plugin.js` into that folder.
6. Return to Discord and enable **UserVoiceVolume**.

If the plugin does not appear, restart Discord once.

## Usage

1. Join a voice channel.
2. Right-click a user.
3. Open **Voice volume+**.
4. Pick a preset from 25% to 300%.

The plugin asks Discord's local media engine to change that user's playback volume. It does not change the other person's microphone or account settings.

## Updating

Replace the old `UserVoiceVolume.plugin.js` file in your BetterDiscord Plugins folder with the newer release and reload/restart Discord.

## Troubleshooting

### “Discord voice modules were not found”
Discord's internal modules can change after an update. Check this repository for a newer release or open an issue with your Discord and BetterDiscord versions.

### The menu does not appear
Make sure the plugin is enabled, then reload Discord (`Ctrl+R`) or restart it.

### 300% is too loud
High amplification can distort audio and sudden loud sounds may be uncomfortable. Start lower and increase only as needed.

## Development

There is no build step. Edit `UserVoiceVolume.plugin.js`, place it in your BetterDiscord Plugins folder, then reload Discord to test changes.

Repository structure:

```text
UserVoiceVolume/
├── UserVoiceVolume.plugin.js
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── SECURITY.md
└── .github/
```

## Contributing

Bug reports and pull requests are welcome. See `CONTRIBUTING.md` before submitting a change.

## Security & privacy

The plugin does not intentionally transmit data anywhere. Per-user preset values are stored locally using BetterDiscord's data API. See `SECURITY.md` for reporting security issues.

## Compatibility notice

BetterDiscord plugins rely on Discord/BetterDiscord APIs that can change. A future Discord update may temporarily break this plugin. This repository is intended to track and fix those compatibility issues openly.

## License

MIT License — see `LICENSE`.
