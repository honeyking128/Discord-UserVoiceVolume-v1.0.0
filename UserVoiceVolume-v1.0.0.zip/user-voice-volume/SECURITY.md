# Security Policy

Please do not publish sensitive security reports containing credentials or private user data in a public issue.

For ordinary compatibility bugs, use GitHub Issues. The plugin should not collect credentials, tokens, message content, or telemetry and should not make unrelated network requests.
