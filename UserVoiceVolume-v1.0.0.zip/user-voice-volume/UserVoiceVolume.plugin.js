/**
 * @name UserVoiceVolume
 * @author Simon Opatrny
 * @version 1.0.0
 * @description Adds quick per-user voice volume presets up to 300% in Discord's user context menu.
 * @source https://github.com/YOUR_USERNAME/UserVoiceVolume
 */
module.exports = class UserVoiceVolume {
  constructor() {
    this.name = "UserVoiceVolume";
    this.version = "1.0.0";
    this.patched = false;
  }

  start() {
    this.patchContextMenu();
    BdApi.UI.showToast(`${this.name} enabled`, { type: "success" });
  }

  stop() {
    BdApi.Patcher.unpatchAll(this.name);
    this.patched = false;
  }

  patchContextMenu() {
    if (this.patched) return;
    const menu = BdApi.ContextMenu;
    const VolumeStore = BdApi.Webpack.getStore("MediaEngineStore");
    const MediaEngineActions = BdApi.Webpack.getModule(m => typeof m?.setLocalVolume === "function", { searchExports: true });

    if (!VolumeStore || !MediaEngineActions) {
      BdApi.UI.showToast("UserVoiceVolume: Discord voice modules were not found.", { type: "error" });
      return;
    }

    const applyVolume = (userId, value) => {
      try {
        MediaEngineActions.setLocalVolume(userId, value);
        BdApi.Data.save(this.name, `volume:${userId}`, value);
        BdApi.UI.showToast(`Volume set to ${value}%`, { type: "success" });
      } catch (error) {
        console.error(`[${this.name}] Failed to set volume`, error);
        BdApi.UI.showToast("Could not change user volume.", { type: "error" });
      }
    };

    menu.patch("user-context", (tree, props) => {
      const userId = props?.user?.id;
      if (!userId) return;
      const presets = [25, 50, 100, 150, 200, 250, 300];
      const saved = BdApi.Data.load(this.name, `volume:${userId}`);

      const children = presets.map(value =>
        menu.buildItem({
          type: "radio",
          label: `${value}%`,
          checked: Number(saved) === value,
          action: () => applyVolume(userId, value)
        })
      );

      const item = menu.buildItem({
        type: "submenu",
        label: "Voice volume+",
        children
      });
      tree?.props?.children?.push(item);
    });

    this.patched = true;
  }
};
