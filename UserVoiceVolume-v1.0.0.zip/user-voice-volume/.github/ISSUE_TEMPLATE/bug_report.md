---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

**Plugin version:**
**Discord version:**
**BetterDiscord version:**

**What happened?**

**Steps to reproduce**
1.
2.
3.

**Console errors (remove private information):**
